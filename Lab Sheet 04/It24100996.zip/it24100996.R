#1
setwd("C://Users//it24100996//Desktop//It24100996")
data <- rle("Exeead.tabrcise.txt", header = TRUE, sep = ",")

#2
str(data)

#3
boxplot(data$Sales_X1,
        main = "Boxplot of Sales",
        ylab = "Sales",
        col = "lightblue",
        border = "darkblue")
summary(data$Sales_X1)

#4
fivenum(data$Advertising_X2)
IQR(data$Advertising_X2)
summary(data$Advertising_X2)

#5
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}
