getwd()
setwd("C:\\Users\\it24100996\\Desktop\\IT24100996")
#Q1
student_data <- read.csv("C:\\Users\\it24100996\\Desktop\\IT24100996", header = TRUE)
head(student_data)
student_data <- read.csv("C:\\Users\\it24100996\\Desktop\\IT24100996\\Exercise.csv", header = TRUE)
head(student_data)
#Q2
summary(student_data$X1)
hist(student_data$X1, main = "Histogram of Age (X1)", xlab = "Age", col = "lightblue", border = "black")
#Q3
table(student_data$X2)
barplot(table(student_data$X2), main = "Bar Chart of Gender (X2)", xlab = "Gender", ylab = "Frequency", col = c("pink", "lightblue"))
#Q4
boxplot(X1 ~ X3, data = student_data, main = "Age (X1) by Accommodation Type (X3)", xlab = "Accommodation Type (X3)", ylab = "Age (X1)", col = c("lightgreen", "lightyellow", "lightpink"))